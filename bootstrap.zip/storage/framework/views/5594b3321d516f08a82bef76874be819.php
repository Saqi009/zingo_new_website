<?php $__env->startSection('title', 'Zingo - assist data security'); ?>

<?php $__env->startSection('content'); ?>

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Start Banner
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="banner-section two inner">
        <div class="banner-element-four two">
            <img src="<?php echo e(asset('assets/images/element/element-5.png')); ?>" alt="element">
        </div>
        <div class="banner-element-five two">
            <img src="<?php echo e(asset('assets/images/element/element-7.png')); ?>" alt="element">
        </div>
        <div class="banner-element-nineteen two">
            <img src="<?php echo e(asset('assets/images/element/element-6.png')); ?>" alt="element">
        </div>
        <div class="banner-element-twenty-two two">
            <img src="<?php echo e(asset('assets/images/element/element-69.png')); ?>" alt="element">
        </div>
        <div class="banner-element-twenty-three two">
            <img src="<?php echo e(asset('assets/images/element/element-70.png')); ?>" alt="element">
        </div>
        <div class="container">
            <div class="row justify-content-center align-items-center mb-30-none">
                <div class="col-xl-12 mb-30">
                    <div class="banner-content two">
                        <div class="banner-content-header">
                            <h2 class="title">Data Security Services</h2>
                            <div class="breadcrumb-area">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Data Security</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    End Banner
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    Start Scroll-To-Top
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <a href="#" class="scrollToTop"><i class="las la-angle-double-up"></i></a>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    End Scroll-To-Top
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    Start Service
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="service-section two ptb-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-12">
                    <div class="service-item three details">
                        <div class="service-thumb">
                            <img src="<?php echo e(asset('assets/images/service.png')); ?>" alt="service">
                        </div>
                        <div class="service-content">
                            <h2 class="title">Comprehensive Data Security Solutions</h2>
                            <p>Our Data Security services are designed to protect your business and customer data through advanced encryption, threat detection, and continuous monitoring. We help mitigate risks and safeguard sensitive information with proactive measures tailored to your organization's needs. With our expertise, you can ensure data privacy, compliance, and business continuity.</p>

                            <div class="service-widget-item-area">
                                <div class="row justify-content-center mb-30-none">
                                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-30">
                                        <div class="service-widget-item">
                                            <div class="service-widget-icon">
                                                <img src="<?php echo e(asset('assets/images/icon/icon-17.png')); ?>" alt="icon">
                                            </div>
                                            <div class="service-widget-content">
                                                <h5 class="title">PROACTIVE THREAT DETECTION</h5>
                                                <span class="sub-title">Targeted insights for impactful results</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-30">
                                        <div class="service-widget-item">
                                            <div class="service-widget-icon">
                                                <img src="<?php echo e(asset('assets/images/icon/icon-18.png')); ?>" alt="icon">
                                            </div>
                                            <div class="service-widget-content">
                                                <h5 class="title">Multi-Layered Defense</h5>
                                                <span class="sub-title">A combination of network, endpoint, and application security to ensure a 360° defense strategy.</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-30">
                                        <div class="service-widget-item">
                                            <div class="service-widget-icon">
                                                <img src="<?php echo e(asset('assets/images/icon/icon-19.png')); ?>" alt="icon">
                                            </div>
                                            <div class="service-widget-content">
                                                <h5 class="title">Incident Response</h5>
                                                <span class="sub-title">Minimize damage and recover quickly with an efficient incident response plan.
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-30">
                                        <div class="service-widget-item">
                                            <div class="service-widget-icon">
                                                <img src="<?php echo e(asset('assets/images/icon/icon-20.png')); ?>" alt="icon">
                                            </div>
                                            <div class="service-widget-content">
                                                <h5 class="title">Continuous Optimization</h5>
                                                <span class="sub-title">Constant updates and enhancements to adapt to emerging threats and technologies.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="service-bottom-content">
                                <h2 class="title">Why Choose Our Data Security Services?</h2>
                                <p>
                                    Our Data Security solutions are designed to provide robust protection while ensuring seamless operations for your business. We help you identify vulnerabilities, eliminate risks, and ensure the safety of sensitive data from unauthorized access or breaches.
                                </p>
                                <p>
                                    By utilizing state-of-the-art encryption, threat intelligence, and real-time surveillance tools, we provide round-the-clock security for your business operations. Whether you're a startup or an established enterprise, our customized solutions ensure that your data is well-protected and your systems are resilient against cyber threats.
                                </p>

                                <blockquote class="two">
                                    <div class="quote-area d-flex flex-wrap">
                                        <div class="quote-icon">
                                            <img src="<?php echo e(asset('assets/images/client/quote-2.png')); ?>" alt="quote">
                                        </div>
                                        <div class="quote-shape">
                                            <img src="<?php echo e(asset('assets/images/element/element-66.png')); ?>" alt="element">
                                        </div>
                                        <div class="quote-content-area">
                                            <p class="quote-content">Data security is the backbone of business continuity. Protecting your data means safeguarding your future."</p>
                                        </div>
                                    </div>
                                </blockquote>
                                <p>
                                    With our comprehensive approach, we enable your business to thrive without worrying about data breaches. Through strategic consultation and implementation of tailored security policies, your business stays protected, and your data remains private.
                                </p>
                                <div class="contact-section two">
                                    <div class="contact-area">
                                        <div class="contact-element-five">
                                            <img src="<?php echo e(asset('assets/images/element/element-60.png')); ?>" alt="element">
                                        </div>
                                        <div class="contact-element-six">
                                            <img src="<?php echo e(asset('assets/images/element/element-60.png')); ?>" alt="element">
                                        </div>
                                        <div class="row mb-30-none">
                                            <div class="col-xl-5 col-lg-5 mb-30">
                                                <div class="contact-thumb">
                                                    <img src="<?php echo e(asset('assets/images/webdev-contact.jpg')); ?>" alt="contact">
                                                </div>
                                            </div>
                                            <div class="col-xl-7 col-lg-7 mb-30">
                                                <div class="contact-form-area">
                                                    <div class="contact-form-header">
                                                        <div class="left">
                                                            <h2 class="title">Get in Touch <span class="text--base">Let's
                                                                    Talk</span></h2>
                                                            <p>Contact us today for a consultation on how we can help secure your business data.</p>
                                                        </div>
                                                    </div>
                                                    <form class="contact-form" id="contact-form">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="row justify-content-center mb-25-none">
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Enter Your Name</label>
                                                                <input type="text" name="name" id="name"
                                                                    class="form--control" placeholder="Name">
                                                            </div>
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Enter Your Email Address</label>
                                                                <input type="email" name="email" id="email"
                                                                    class="form--control" placeholder="Email">
                                                            </div>
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Enter Your Phone</label>
                                                                <input type="text" name="phone" id="phone"
                                                                    class="form--control" placeholder="xxxxxxxxxx"
                                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                                                            </div>
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Select Subject</label>
                                                                <div class="contact-select">
                                                                    <select class="form--control" name="service"
                                                                        id="service">
                                                                        <option value="" selected>Choose subject
                                                                        </option>
                                                                        <option value="virtual_assistant">Virtual Assistant
                                                                        </option>
                                                                        <option value="web_development">Web Development
                                                                        </option>
                                                                        <option value="web_design">Web Design</option>
                                                                        <option value="search_seo">Search SEO</option>
                                                                        <option value="email_and_text_marketing">Email and
                                                                            Text Marketing</option>
                                                                        <option value="lead_generation">Lead Generation
                                                                        </option>
                                                                        <option value="transaction_cordinator">Transaction
                                                                            Cordination</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-12 col-lg-12 form-group">
                                                                <label>Write Message</label>
                                                                <textarea name="message" class="form--control" id="message" name="message" placeholder="Write Here ..."></textarea>
                                                            </div>
                                                            <div class="col-xl-12 col-lg-12 form-group text-center">
                                                                <button type="submit" name="submit"
                                                                    class="btn--base mt-20">Send Now <i
                                                                        class="fas fa-arrow-right ml-2"></i></button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    End Service
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <?php echo $__env->make('partials.trail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials.popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        const sendEmailRoute = <?php echo json_encode(route('api.send_email'), 15, 512) ?>;
    </script>

    <script src="<?php echo e(asset('assets/custom/custom.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\ZINGO\zingo_assist\resources\views/services/data_security.blade.php ENDPATH**/ ?>