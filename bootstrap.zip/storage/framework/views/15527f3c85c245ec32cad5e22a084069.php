<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($mail_data['title']); ?></title>
</head>
<body>
    <p>Name: <?php echo e($mail_data['name']); ?></p>
    <p>Email: <?php echo e($mail_data['email']); ?></p>
    <p>Phone: <?php echo e($mail_data['phone']); ?></p>
    <p>Service: <?php echo e($mail_data['service']); ?></p>
    <p>message: <?php echo e($mail_data['message']); ?></p>
</body>
</html>
<?php /**PATH C:\Users\hp440\Desktop\Program\ZINGO\zingo_assist\resources\views/email/show.blade.php ENDPATH**/ ?>