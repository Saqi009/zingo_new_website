<?php $__env->startSection('title', 'Zingo - Lead Generation'); ?>

<?php $__env->startSection('content'); ?>

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            Start Banner
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="banner-section two inner">
        <div class="banner-element-four two">
            <img src="<?php echo e(asset('assets/images/element/element-5.png')); ?>" alt="element">
        </div>
        <div class="banner-element-five two">
            <img src="<?php echo e(asset('assets/images/element/element-7.png')); ?>" alt="element">
        </div>
        <div class="banner-element-nineteen two">
            <img src="<?php echo e(asset('assets/images/element/element-6.png')); ?>" alt="element">
        </div>
        <div class="banner-element-twenty-two two">
            <img src="<?php echo e(asset('assets/images/element/element-69.png')); ?>" alt="element">
        </div>
        <div class="banner-element-twenty-three two">
            <img src="<?php echo e(asset('assets/images/element/element-70.png')); ?>" alt="element">
        </div>
        <div class="container">
            <div class="row justify-content-center align-items-center mb-30-none">
                <div class="col-xl-12 mb-30">
                    <div class="banner-content two">
                        <div class="banner-content-header">
                            <h2 class="title">Lead Generation</h2>
                            <div class="breadcrumb-area">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Lead Generation</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        End Banner
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Start Scroll-To-Top
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <a href="#" class="scrollToTop"><i class="las la-angle-double-up"></i></a>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        End Scroll-To-Top
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Start Service
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="service-section two ptb-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-12">
                    <div class="service-item three details">
                        <div class="service-thumb">
                            <img src="<?php echo e(asset('assets/images/services/lead_generation.png')); ?>" alt="service">
                        </div>
                        <div class="service-content">
                            <h2 class="title">Lead Generation</h2>
                            <p>Our Lead Generation services help businesses generate high-quality leads and potential customers for their products and services. Through a strategic combination of online campaigns, content marketing, and data-driven tactics, we deliver a consistent flow of qualified leads to help you grow your business.</p>

                            <div class="service-widget-item-area">
                                <div class="row justify-content-center mb-30-none">
                                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-30">
                                        <div class="service-widget-item">
                                            <div class="service-widget-icon">
                                                <img src="<?php echo e(asset('assets/images/icon/icon-17.png')); ?>" alt="icon">
                                            </div>
                                            <div class="service-widget-content">
                                                <h5 class="title">TARGETED CAMPAIGNS</h5>
                                                <span class="sub-title">Reach your ideal audience with precision</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-30">
                                        <div class="service-widget-item">
                                            <div class="service-widget-icon">
                                                <img src="<?php echo e(asset('assets/images/icon/icon-18.png')); ?>" alt="icon">
                                            </div>
                                            <div class="service-widget-content">
                                                <h5 class="title">INBOUND MARKETING</h5>
                                                <span class="sub-title">Attract customers with valuable content</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-30">
                                        <div class="service-widget-item">
                                            <div class="service-widget-icon">
                                                <img src="<?php echo e(asset('assets/images/icon/icon-19.png')); ?>" alt="icon">
                                            </div>
                                            <div class="service-widget-content">
                                                <h5 class="title">CONVERSION OPTIMIZATION</h5>
                                                <span class="sub-title">Increase conversions from leads</span>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-30">
                                        <div class="service-widget-item">
                                            <div class="service-widget-icon">
                                                <img src="<?php echo e(asset('assets/images/icon/icon-20.png')); ?>" alt="icon">
                                            </div>
                                            <div class="service-widget-content">
                                                <h5 class="title">CRM INTEGRATION</h5>
                                                <span class="sub-title">Automate lead management and follow-ups</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="service-bottom-content">
                                <h2 class="title">Service Description</h2>
                                <p>
                                    Our Lead Generation services help businesses build an efficient pipeline of potential customers. By leveraging inbound marketing strategies, such as content creation, SEO, and social media campaigns, we drive traffic to your business and convert visitors into leads. Our approach ensures that the leads you receive are relevant, highly-targeted, and likely to convert into sales.
                                </p>
                                <p>
                                    Whether you're looking to generate leads for B2B or B2C, we tailor our strategies to fit your business objectives. Our comprehensive approach includes optimizing your website for lead capture, running targeted advertising campaigns, and utilizing email marketing to nurture leads through the sales funnel.
                                </p>
                                <blockquote class="two">
                                    <div class="quote-area d-flex flex-wrap">
                                        <div class="quote-icon">
                                            <img src="<?php echo e(asset('assets/images/client/quote-2.png')); ?>" alt="quote">
                                        </div>
                                        <div class="quote-shape">
                                            <img src="<?php echo e(asset('assets/images/element/element-66.png')); ?>" alt="element">
                                        </div>
                                        <div class="quote-content-area">
                                            <p class="quote-content">"Lead Generation is not just about capturing contacts—it's about connecting with your ideal customers and turning them into loyal buyers."</p>

                                        </div>
                                    </div>
                                </blockquote>
                                <p>
                                    Our team utilizes proven tactics like SEO-optimized landing pages, paid search campaigns, retargeting ads, and engaging social media posts to attract high-quality leads. We combine creative content with data-driven insights to ensure that every lead is well-qualified and has the potential to become a loyal customer.
                                </p>
                                <p>
                                    With our Lead Generation services, we help businesses increase their sales opportunities and grow their customer base, ultimately driving revenue growth.
                                </p>
                                <div class="contact-section two">
                                    <div class="contact-area">
                                        <div class="contact-element-five">
                                            <img src="<?php echo e(asset('assets/images/element/element-60.png')); ?>" alt="element">
                                        </div>
                                        <div class="contact-element-six">
                                            <img src="<?php echo e(asset('assets/images/element/element-60.png')); ?>" alt="element">
                                        </div>
                                        <div class="row mb-30-none">
                                            <div class="col-xl-5 col-lg-5 mb-30">
                                                <div class="contact-thumb">
                                                    <img src="<?php echo e(asset('assets/images/webdev-contact.jpg')); ?>"
                                                        alt="contact">
                                                </div>
                                            </div>
                                            <div class="col-xl-7 col-lg-7 mb-30">
                                                <div class="contact-form-area">
                                                    <div class="contact-form-header">
                                                        <div class="left">
                                                            <h2 class="title">Get in Touch <span class="text--base">Let's
                                                                    Talk</span></h2>
                                                                    <p>Contact us to find out how we can help you grow your business with lead generation!</p>
                                                                </div>
                                                    </div>
                                                    <form class="contact-form" id="contact-form">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="row justify-content-center mb-25-none">
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Enter Your Name</label>
                                                                <input type="text" name="name" id="name"
                                                                    class="form--control" placeholder="Name">
                                                            </div>
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Enter Your Email Address</label>
                                                                <input type="email" name="email" id="email"
                                                                    class="form--control" placeholder="Email">
                                                            </div>
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Enter Your Phone</label>
                                                                <input type="text" name="phone" id="phone"
                                                                    class="form--control" placeholder="xxxxxxxxxx"
                                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                                                            </div>
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Select Subject</label>
                                                                <div class="contact-select">
                                                                    <select class="form--control" name="service"
                                                                        id="service">
                                                                        <option value="" selected>Choose subject
                                                                        </option>
                                                                        <option value="virtual_assistant">Virtual Assistant
                                                                        </option>
                                                                        <option value="web_development">Web Development
                                                                        </option>
                                                                        <option value="web_design">Web Design</option>
                                                                        <option value="search_seo">Search SEO</option>
                                                                        <option value="email_and_text_marketing">Email and
                                                                            Text Marketing</option>
                                                                        <option value="lead_generation">Lead Generation
                                                                        </option>
                                                                        <option value="transaction_cordinator">Transaction
                                                                            Cordination</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-12 col-lg-12 form-group">
                                                                <label>Write Message</label>
                                                                <textarea name="message" class="form--control" id="message" name="message" placeholder="Write Here ..."></textarea>
                                                            </div>
                                                            <div class="col-xl-12 col-lg-12 form-group text-center">
                                                                <button type="submit" name="submit"
                                                                    class="btn--base mt-20">Send Now <i
                                                                        class="fas fa-arrow-right ml-2"></i></button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        End Service
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <?php echo $__env->make('partials.trail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials.popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        const sendEmailRoute = <?php echo json_encode(route('api.send_email'), 15, 512) ?>;
    </script>

    <script src="<?php echo e(asset('assets/custom/custom.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\ZINGO\zingo_assist\resources\views/services/lead_generation.blade.php ENDPATH**/ ?>