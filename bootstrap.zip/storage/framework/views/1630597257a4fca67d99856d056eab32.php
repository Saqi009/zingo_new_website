<div class="pooo">
    <!-- Popup Form Wrapper -->
    <div class="popup-wrapper" id="popupWrapper">
        <div class="popup-container">
            <div id="alert"></div>
            <form action="" id="trail_form" method="post">
                <?php echo csrf_field(); ?>
                <button class="btn-close-popup" onclick="hidePopup()">X</button>
                <h2 style="color: #A52673">2 Days Free Trail</h2>
                <input type="email" name="email" id="email" placeholder="Your Email">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input class="mb-2 is-invalid" type="phone" name="phone" id="phone" placeholder="Your Phone">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger "><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <textarea name="message" id="message" cols="30" rows="2" placeholder="Message.."></textarea>
                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="submit" class="btn-submit mt-1">
                
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\hp440\Desktop\Program\ZINGO\zingo_assist\resources\views/partials/trail.blade.php ENDPATH**/ ?>