
<div id="popup" class="popup">
    <div class="popup-content">
        <span class="close-btn" id="closeBtn">&times;</span>
        <h2>Thank You!</h2>
        <p>Thank you for contacting us. We will get back to you shortly.</p>
    </div>
</div>



<?php /**PATH C:\Users\hp440\Desktop\Program\ZINGO\zingo_assist\resources\views/partials/popup.blade.php ENDPATH**/ ?>