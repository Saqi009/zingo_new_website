<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

    <!--~~~~~~~~~Start Preloader~~~~-->
    
    <!--~~~~~ End Preloader ~~~-->


    <div class="cursor"></div>
    <div class="cursor-follower"></div>


    <!--~~~~ Start Header ~~~~~~~-->
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--~~~~~~~~~~  End Header ~~~~~~~-->

    <?php echo $__env->yieldContent('content'); ?>

    <!--~~~~~~~~~  Start Footer ~~~~~~~~-->
    
    <!--~~~~~~~ End Footer ~~~~~~~~~~~-->

    <?php echo $__env->make('partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\hp440\Desktop\Program\ZINGO\zingo_assist\resources\views/layout/main.blade.php ENDPATH**/ ?>