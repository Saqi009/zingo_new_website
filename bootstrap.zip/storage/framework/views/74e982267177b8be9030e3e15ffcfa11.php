<?php $__env->startSection('title', 'Zingo - assist blog'); ?>

<head>
    <style>
        .header-section {
            background: #A52673;
        }
    </style>
</head>

<?php $__env->startSection('content'); ?>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Start Banner
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="banner-section two inner">
        <div class="banner-element-four two">
            <img src="assets/images/element/element-5.png" alt="element">
        </div>
        <div class="banner-element-five two">
            <img src="assets/images/element/element-7.png" alt="element">
        </div>
        <div class="banner-element-nineteen two">
            <img src="assets/images/element/element-6.png" alt="element">
        </div>
        <div class="banner-element-twenty-two two">
            <img src="assets/images/element/element-69.png" alt="element">
        </div>
        <div class="banner-element-twenty-three two">
            <img src="assets/images/element/element-70.png" alt="element">
        </div>
        <div class="container">
            <div class="row justify-content-center align-items-center mb-30-none">
                <div class="col-xl-12 mb-30">
                    <div class="banner-content two">
                        <div class="banner-content-header">
                            <h2 class="title">Our Teams</h2>
                            <div class="breadcrumb-area">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Teams</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        End Banner
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Start Scroll-To-Top
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <a href="#" class="scrollToTop"><i class="las la-angle-double-up"></i></a>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        End Scroll-To-Top
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Start Team
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="team-section three ptb-120">
        <div class="container">
            <div class="row justify-content-center mb-65-none">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-60">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="assets/images/team/team-4.png" alt="team">
                        </div>
                        <div class="team-content">
                            <h3 class="title"><a href="team-details.html">Khan</a></h3>
                            <span class="sub-title">CEO</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-60">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="assets/images/team/team-5.png" alt="team">
                        </div>
                        <div class="team-content">
                            <h3 class="title"><a href="team-details.html">Zack Smith</a></h3>
                            <span class="sub-title">Project Manager</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-60">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="assets/images/team/team-6.png" alt="team">
                        </div>
                        <div class="team-content">
                            <h3 class="title"><a href="team-details.html">Lisa Hasty</a></h3>
                            <span class="sub-title">Project Cordinator</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-60">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="assets/images/team/team-7.png" alt="team">
                        </div>
                        <div class="team-content">
                            <h3 class="title"><a href="team-details.html">Haris Brown</a></h3>
                            <span class="sub-title">Operational Manager</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-60">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="assets/images/team/team-8.png" alt="team">
                        </div>
                        <div class="team-content">
                            <h3 class="title"><a href="team-details.html">Ilsa Grace</a></h3>
                            <span class="sub-title">Floor Manager</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-60">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="assets/images/team/team-2.png" alt="team">
                        </div>
                        <div class="team-content">
                            <h3 class="title"><a href="team-details.html">Nancy Byers</a></h3>
                            <span class="sub-title">Web Developer</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-60">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="assets/images/team/team-1.png" alt="team">
                        </div>
                        <div class="team-content">
                            <h3 class="title"><a href="team-details.html">James Buttler</a></h3>
                            <span class="sub-title">Bussiness Developer</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-60">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="assets/images/team/team-9.png" alt="team">
                        </div>
                        <div class="team-content">
                            <h3 class="title"><a href="team-details.html">Warda</a></h3>
                            <span class="sub-title">HR</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 mb-60">
                    <div class="team-item">
                        <div class="team-thumb">
                            <img src="assets/images/team/team-10.png" alt="team">
                        </div>
                        <div class="team-content">
                            <h3 class="title"><a href="team-details.html">Chris Collins</a></h3>
                            <span class="sub-title">A.E</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        End Team
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\ZINGO\zingo_assist\resources\views/team.blade.php ENDPATH**/ ?>