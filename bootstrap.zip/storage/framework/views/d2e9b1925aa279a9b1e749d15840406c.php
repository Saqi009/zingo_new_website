<?php $__env->startSection('title', 'Zingo - Assist Cold Calling'); ?>

<?php $__env->startSection('content'); ?>

    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            Start Banner
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="banner-section two inner">
        <div class="banner-element-four two">
            <img src="<?php echo e(asset('assets/images/element/element-5.png')); ?>" alt="element">
        </div>
        <div class="banner-element-five two">
            <img src="<?php echo e(asset('assets/images/element/element-7.png')); ?>" alt="element">
        </div>
        <div class="banner-element-nineteen two">
            <img src="<?php echo e(asset('assets/images/element/element-6.png')); ?>" alt="element">
        </div>
        <div class="banner-element-twenty-two two">
            <img src="<?php echo e(asset('assets/images/element/element-69.png')); ?>" alt="element">
        </div>
        <div class="banner-element-twenty-three two">
            <img src="<?php echo e(asset('assets/images/element/element-70.png')); ?>" alt="element">
        </div>
        <div class="container">
            <div class="row justify-content-center align-items-center mb-30-none">
                <div class="col-xl-12 mb-30">
                    <div class="banner-content two">
                        <div class="banner-content-header">
                            <h2 class="title">Cold Calling</h2>
                            <div class="breadcrumb-area">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Cold Calling</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        End Banner
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Start Scroll-To-Top
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <a href="#" class="scrollToTop"><i class="las la-angle-double-up"></i></a>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        End Scroll-To-Top
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Start Service
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <section class="service-section two ptb-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-12">
                    <div class="service-item three details">
                        <div class="service-thumb">
                            <img src="<?php echo e(asset('assets/images/services/it_support.png')); ?>" alt="service">
                        </div>
                        <div class="service-content">
                            <h2 class="title">Cold Calling</h2>
                            <p>Unlock the potential of cold calling with our specialized, results-driven approach! Cold
                                calling remains one of the most effective ways to reach new customers, generate leads, and
                                build strong relationships from the first point of contact. A Zingo Assist, we combine
                                proven techniques with a personalized touch to make every call count.
                            </p>
                            <div class="service-bottom-content">
                                <h2 class="title">Service Description</h2>
                                <p>
                                    Our team of experienced cold callers is trained to engage potential clients, adapt to
                                    various industries, and customize their pitch to resonate with each prospect. Whether
                                    it's real estate, B2B services, or other industries, we aim to spark interest and create
                                    opportunities that align with your goals.

                                    What makes our cold calling unique? We believe in quality over quantity. Each
                                    conversation is structured to build rapport, address concerns, and convey value —
                                    ensuring every call moves your business forward. Our services cover everything from lead
                                    generation and follow-ups to detailed reporting and analytics, so you’re always in the
                                    loop.

                                    Empower your business with a dedicated cold calling team that turns cold leads into warm
                                    prospects. Ready to expand your reach? Contact us today to learn more about our cold
                                    calling solutions and discover how we can help you connect, convert, and grow.</p>
                                <p>Our multi-channel approach encompasses social media management, SEO, content
                                    creation, email marketing, and pay-per-click advertising, providing a cohesive
                                    digital strategy that aligns with your unique goals. With compelling content and
                                    creative campaigns, we capture your audience’s attention, build trust, and encourage
                                    action—whether it’s a purchase, sign-up, or engagement with your brand.</p>
                                <div class="contact-section two">
                                    <div class="contact-area">
                                        <div class="contact-element-five">
                                            <img src="<?php echo e(asset('assets/images/element/element-60.png')); ?>" alt="element">
                                        </div>
                                        <div class="contact-element-six">
                                            <img src="<?php echo e(asset('assets/images/element/element-60.png')); ?>" alt="element">
                                        </div>
                                        <div class="row mb-30-none">
                                            <div class="col-xl-5 col-lg-5 mb-30">
                                                <div class="contact-thumb">
                                                    <img src="<?php echo e(asset('assets/images/webdev-contact.jpg')); ?>"
                                                        alt="contact">
                                                </div>
                                            </div>
                                            <div class="col-xl-7 col-lg-7 mb-30">
                                                <div class="contact-form-area">
                                                    <div class="contact-form-header">
                                                        <div class="left">
                                                            <h2 class="title">Get in Touch <span class="text--base">Let's
                                                                    Talk</span></h2>
                                                            <p>Contact Us for further detail!</p>
                                                        </div>
                                                    </div>
                                                    <form class="contact-form" id="contact-form">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="row justify-content-center mb-25-none">
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Enter Your Name</label>
                                                                <input type="text" name="name" id="name"
                                                                    class="form--control" placeholder="Name">
                                                            </div>
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Enter Your Email Address</label>
                                                                <input type="email" name="email" id="email"
                                                                    class="form--control" placeholder="Email">
                                                            </div>
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Enter Your Phone</label>
                                                                <input type="text" name="phone" id="phone"
                                                                    class="form--control" placeholder="xxxxxxxxxx"
                                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                                                            </div>
                                                            <div class="col-xl-6 col-lg-6 form-group">
                                                                <label>Select Subject</label>
                                                                <div class="contact-select">
                                                                    <select class="form--control" name="service"
                                                                        id="service">
                                                                        <option value="" selected>Choose subject
                                                                        </option>
                                                                        <option value="virtual_assistant">Virtual Assistant
                                                                        </option>
                                                                        <option value="web_development">Web Development
                                                                        </option>
                                                                        <option value="web_design">Web Design</option>
                                                                        <option value="search_seo">Search SEO</option>
                                                                        <option value="email_and_text_marketing">Email and
                                                                            Text Marketing</option>
                                                                        <option value="lead_generation">Lead Generation
                                                                        </option>
                                                                        <option value="transaction_cordinator">Transaction
                                                                            Cordination</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-xl-12 col-lg-12 form-group">
                                                                <label>Write Message</label>
                                                                <textarea name="message" class="form--control" id="message" name="message" placeholder="Write Here ..."></textarea>
                                                            </div>
                                                            <div class="col-xl-12 col-lg-12 form-group text-center">
                                                                <button type="submit" name="submit"
                                                                    class="btn--base mt-20">Send Now <i
                                                                        class="fas fa-arrow-right ml-2"></i></button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        End Service
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

    <?php echo $__env->make('partials.trail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials.popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        const sendEmailRoute = <?php echo json_encode(route('api.send_email'), 15, 512) ?>;
    </script>

    <script src="<?php echo e(asset('assets/custom/custom.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp440\Desktop\Program\ZINGO\zingo_assist\resources\views/services/it_management.blade.php ENDPATH**/ ?>