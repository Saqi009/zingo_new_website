<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Softim | Documentation</title>
    <meta name="description" content="Thanks for purchasing Softim. If you need any support, please contact with us.">
    <meta name="author" content="Themeim">
    <meta name="copyright" content="Themeim">
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="shortcut icon" type="image/png" href="img/fav.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="wrapper">
        <div class="left-side">
            <div class="logo">
                <a href="/">
                    <img src="img/logo.png" alt="logo">
                </a>

            </div>
            <div class="left-content">
                <ul role="tablist">
                    <li role="presentation" class="active"><a href="#one" aria-controls="home" role="tab" data-toggle="tab"><span><i class="fa fa-home"></i></span>Welcome</a></li>
                    <li role="presentation" ><a href="#two" aria-controls="home" role="tab" data-toggle="tab"><span><i class="fa fa-folder"></i></span>Main File Structure</a></li>
                    <li role="presentation" ><a href="#three" aria-controls="home" role="tab" data-toggle="tab"><span><i class="fa fa-code"></i></span>HTML Structure</a></li>
                    <li role="presentation" ><a href="#four" aria-controls="home" role="tab" data-toggle="tab"><span><i class="fa fa-css3"></i></span>CSS Structure</a></li>
                    <li role="presentation" ><a href="#scss" aria-controls="home" role="tab" data-toggle="tab"><span><i class="fa fa-save"></i></span>Customization</a></li>
                    <li role="presentation" ><a href="#source" aria-controls="home" role="tab" data-toggle="tab"><span><i class="fa fa-thumbs-up"></i></span>Sources &amp; Credits</a></li>
                    <li role="presentation" ><a href="#support" aria-controls="home" role="tab" data-toggle="tab"><span><i class="fa fa-support"></i></span>Support</a></li>
                </ul>
            </div>
            <div class="copyright">
                <p>Copyright &copy; 2022. <a href="https://themeim.com/">Themeim</a> <span>All Rights Reserved.</span></p>
            </div>
        </div>
        <div class="right-side">
            <div class="right-content">
                <div id="one" class="content active fade in">
                    <h1><span>Softim</span> - It Solution Html Template</h1>
                    <div class="created">
                            <p>
                                Created:  17 March 2022 <br>
                                Latest Update:  18 May 2022 <br>
                                By: <a href="https://themeim.com/">Themeim</a><br>
                                Email: <a href="mailTo:support@themeim.com">support@themeim.com</a><br>
                                <br>
                                Thank you for purchasing our theme. Softim - It Solution Html Template. If you have any question, please feel free to contact us.
                            </p>
                    </div>
                </div>
                <div id="two" class="content fade">
                    <h1>Main File Structure</h1>
                    <p>
                        All the file are well organized, its so easy to work with the template.
                        <br>
                        1. Unzip the files.
                        <br>
                        2. Open "Softim" folder.
                        <br>
                        You will see 4 directories, css, fonts, images and js.
                        <br>
                        In the first folder Content you will find style.css and other styling files the all the other files expect the htmls.
                        <br>
                        Js folder contain only the jquery library. Fonts folder contain essetial font files for fonts.
                    </p>
                <pre>
                <xmp>
                    Softim/
                    |    |                    
                    |    assets
                    |    ├── css/
                    |    |    └── animate.css
                    |    |    └── bootstrap.css
                    |    |    └── fontawesome-all.min.css
                    |    |    └── icomoon.css
                    |    |    └── lightcase.css
                    |    |    └── line-awesome.min.css
                    |    |    └── odometer.css
                    |    |    └── swiper.min.css
                    |    |    └── nice-select.css
                    |    |    └── aos.css
                    |    |    └── style.css
                    |    |
                    |    ├── fonts
                    |    |    └── fa-brands-400.eot
                    |    |    └── fa-brands-400.svg
                    |    |    └── fa-brands-400.ttf
                    |    |    └── fa-brands-400.woff
                    |    |    └── fa-brands-400.woff2
                    |    |    └── fa-regular-400.eot
                    |    |    └── fa-regular-400.svg
                    |    |    └── fa-regular-400.ttf
                    |    |    └── fa-regular-400.woff
                    |    |    └── fa-regular-400.woff2
                    |    |    └── fa-solid-900.eot
                    |    |    └── fa-solid-900.svg
                    |    |    └── fa-solid-900.ttf
                    |    |    └── fa-solid-900.woff
                    |    |    └── fa-solid-900.woff2
                    |    |    └── FontAwesome.otf
                    |    |    └── fontawesome-webfont.eot
                    |    |    └── fontawesome-webfont.svg
                    |    |    └── fontawesome-webfont.ttf
                    |    |    └── fontawesome-webfont.woff
                    |    |    └── fontawesome-webfont.woff2
                    |    |
                    |    ├── js/
                    |         └── bootstrap.min.js
                    |         └── jquery-3.6.0.min.js
                    |         └── lightcase.js
                    |         └── main.js
                    |         └── odometer.min.js
                    |         └── swiper.min.js
                    |         └── viewport.jquery.js
                    |         └── aos.js
                    |         └── tweenmax.js
                    |         └── isotope.js
                    |         └── aos.js
                    │
                    ├── about.html
                    ├── blog.html
                    ├── blog-classic.html
                    ├── blog-details.html
                    ├── contact.html
                    ├── faq.html
                    ├── index.html
                    ├── index-two.html
                    ├── index-three.html
                    ├── plan.html
                    ├── portfolio.html
                    ├── project.html
                    ├── project-details.html
                    ├── service.html
                    ├── service-details.html
                    ├── service-details-two.html
                    ├── service-two.html
                    ├── team.html
                    ├── team-details.html
                </xmp>
                </pre>
                </div>
                <div id="scss" class="content fade">

                        <h1> Customization</h1>

                        <div class="element-container">
                            <h3>How to Change Site Title And Favicon Icon</h3>
                            <img src="img/change_top_menu.png" alt="">
                        </div>

                        <div class="element-container">
                            <h3>How to Change Logo</h3>
                            <img src="img/change_log.png" alt="">
                        </div>

                        <div class="element-container">
                            <h3>How to Change Your Menu Title</h3>
                            <img src="img/change_top_menu.png" alt="">
                        </div>

                        <div class="element-container">
                            <h3>How to Change Slider Image and Text</h3>
                            <img src="img/change_slider.png" alt="">
                        </div>

                        <div class="element-container">
                            <h3>How to Change Phone Number, E-Mail Address and Address</h3>
                            <img src="img/change_phone.png" alt="">
                        </div>

                        <div class="element-container">
                            <h3>How to Change Copyright Text</h3>
                            <img src="img/change_copyright.png" alt="">
                        </div>
    
        </div>
                <div id="three" class="content fade">

                    <h1> HTML Structure</h1>
                    <div>The base structure was organized by row, col-** class </div>
<pre>
<xmp>

<!-- Banner Column Start-->
<div class="col-xl-7 col-lg-7 mb-30">
    <div class="banner-content" data-aos="fade-right" data-aos-duration="1800">
        <h1 class="title">Smarter Way to Serve Digital Product Marketing</h1>
        <span class="sub-title">Build Your Innovations & Digital Future</span>
        <p>Personalization assumed up an excess of position in the showcasing space and has made each and every one of your messages exhausting and without feelings.</p>
        <div class="banner-arrow">
            <img src="assets/images/element/element-1.png" alt="element">
        </div>
        <div class="banner-widget">
            <div class="banner-widget-wrapper">
                <div class="banner-widget-left">
                    <div class="banner-widget-thumb">
                        <img src="assets/images/element/element-2.png" alt="element">
                    </div>
                </div>
                <div class="banner-widget-middle">
                    <div class="banner-widget-content">
                        <p><span>4,000+</span> Satisfied Clients</p>
                    </div>
                </div>
                <div class="banner-widget-right">
                    <div class="banner-widget-btn">
                        <a href="#0" class="btn--base">Let's Talk</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Banner Column End-->

</xmp>
</pre>

    </div>
        <div id="four" class="content fade">
            <h1> CSS Structure</h1>
            <div>The base structure was organized by row, col-** class </div>
            <pre>
                <xmp>
            /*---------------------
                Banner Column
            ----------------------*/
              
            .banner-section .banner-content {
                position: relative;
                z-index: 9;
              }
              .banner-section .banner-content .title {
                margin-bottom: 30px;
                color: #fff;
                font-weight: 700;
                line-height: 1.4;
              }
              @media only screen and (max-width: 991px) {
                .banner-section .banner-content .title {
                  margin-bottom: 10px;
                }
              }
              .banner-section .banner-content .sub-title {
                color: #F8D458;
                font-weight: 600;
                margin-bottom: 15px;
              }
              @media only screen and (max-width: 991px) {
                .banner-section .banner-content .sub-title {
                  font-size: 18px;
                  line-height: 1.4;
                  margin-bottom: 15px;
                }
              }
              .banner-section .banner-content p {
                color: #fff;
                width: 61%;
                line-height: 1.8em;
              }
              @media only screen and (max-width: 991px) {
                .banner-section .banner-content p {
                  width: 100%;
                }
              }
              .banner-section .banner-content.two .banner-content-header {
                text-align: center;
              }
              .banner-section .banner-content.two .title {
                color: #1C1C1C;
                margin-bottom: 0;
              }

                </xmp>
            </pre>
        </div>
    

        
        <div id="source" class="content fade">
            <h1> Sources &amp; Credits </h1>
            <ul>
                <li><span>Fonts</span>
                    <ul>
                        <li><a href='https://fonts.google.com/specimen/Jost?query=Jost'>Jost</a></li>
                        <li><a href='https://fonts.google.com/specimen/Poppins?query=Poppins'>Poppins</a></li>
                    </ul>
                </li>
                <li><span>Icons</span>
                    <ul>
                        <li><a href="https://fontawesome.com/">Fontawesome</a></li>
                        <li><a href="https://icomoon.io/">Icomoon</a></li>
                    </ul>
                </li>

                <li><span>CSS</span>
                    <ul>
                        <li><a href="https://animate.style/">Animate</a></li>
                        <li><a href="https://getbootstrap.com/">Bootstrap</a></li>
                        <li><a href="https://swiperjs.com/demos">Swiper Slide</a></li>
                        <li><a href="https://www.jqueryscript.net/lightbox/Versatile-Responsive-jQuery-LightBox-Plugin-lightcase-js.html">Lightcase</a></li>
                    </ul></li>

                <li><span>JS</span>
                    <ul>
                        <li><a href="https://swiperjs.com/demos">Swiper Slide</a></li>
                        <li><a href="https://getbootstrap.com/">Bootstrap</a></li>
                        <li><a href="https://jquery.com/">Jquery</a></li>
                    </ul></li>
            </ul>
        </div>
        <div id="support" class="content fade">
            <h1> Supports </h1>
            <p>Thank you for reading the documentaion. If you still have any question or any problem, please contact with us. We will give you best support. Thanks.</p>
            <a href="https://themeim.com/">Themeim</a>
        </div>
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-1.11.3.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
